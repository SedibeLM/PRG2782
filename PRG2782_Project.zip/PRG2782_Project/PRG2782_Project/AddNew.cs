﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRG2782_Project
{
    public partial class AddNew : Form
    {
        public AddNew()
        {
            InitializeComponent();
        }

        private void buttonHome_Click(object sender, EventArgs e) //TO GO BACK TO HOME PAGE
        {
            new Home().Show();
            this.Hide();
        }

        private void buttonSubmit_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(numericUpDownID.Value);
            string firstName = textBoxFirstName.Text;
            string lastName = textBoxLastName.Text;
            int age = Convert.ToInt32(numericUpDownAge.Value);
            string course = comboBoxCourse.Text;

            string fileName = Path.GetFileName("students.txt");
            using (StreamWriter sw = File.AppendText(fileName))
            {
                sw.WriteLine(ID + " , " + firstName + " , " + lastName + " , " + age + " , " + course);

            }
        }
    }
}

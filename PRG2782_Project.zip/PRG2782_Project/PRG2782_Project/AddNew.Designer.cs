﻿namespace PRG2782_Project
{
    partial class AddNew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonHome = new Button();
            labelFirstName = new Label();
            textBoxFirstName = new TextBox();
            textBoxLastName = new TextBox();
            labelLastName = new Label();
            numericUpDownID = new NumericUpDown();
            labelAge = new Label();
            labelID = new Label();
            numericUpDownAge = new NumericUpDown();
            labelCourse = new Label();
            comboBoxCourse = new ComboBox();
            buttonSubmit = new Button();
            ((System.ComponentModel.ISupportInitialize)numericUpDownID).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownAge).BeginInit();
            SuspendLayout();
            // 
            // buttonHome
            // 
            buttonHome.Location = new Point(12, 409);
            buttonHome.Name = "buttonHome";
            buttonHome.Size = new Size(94, 29);
            buttonHome.TabIndex = 0;
            buttonHome.Text = "Home";
            buttonHome.UseVisualStyleBackColor = true;
            buttonHome.Click += buttonHome_Click;
            // 
            // labelFirstName
            // 
            labelFirstName.AutoSize = true;
            labelFirstName.Location = new Point(135, 102);
            labelFirstName.Name = "labelFirstName";
            labelFirstName.Size = new Size(83, 20);
            labelFirstName.TabIndex = 1;
            labelFirstName.Text = "First Name:";
            // 
            // textBoxFirstName
            // 
            textBoxFirstName.Location = new Point(270, 102);
            textBoxFirstName.Name = "textBoxFirstName";
            textBoxFirstName.Size = new Size(125, 27);
            textBoxFirstName.TabIndex = 2;
            // 
            // textBoxLastName
            // 
            textBoxLastName.Location = new Point(270, 159);
            textBoxLastName.Name = "textBoxLastName";
            textBoxLastName.Size = new Size(125, 27);
            textBoxLastName.TabIndex = 4;
            // 
            // labelLastName
            // 
            labelLastName.AutoSize = true;
            labelLastName.Location = new Point(135, 159);
            labelLastName.Name = "labelLastName";
            labelLastName.Size = new Size(82, 20);
            labelLastName.TabIndex = 3;
            labelLastName.Text = "Last Name:";
            // 
            // numericUpDownID
            // 
            numericUpDownID.Location = new Point(273, 65);
            numericUpDownID.Name = "numericUpDownID";
            numericUpDownID.Size = new Size(150, 27);
            numericUpDownID.TabIndex = 5;
            // 
            // labelAge
            // 
            labelAge.AutoSize = true;
            labelAge.Location = new Point(135, 213);
            labelAge.Name = "labelAge";
            labelAge.Size = new Size(39, 20);
            labelAge.TabIndex = 6;
            labelAge.Text = "Age:";
            // 
            // labelID
            // 
            labelID.AutoSize = true;
            labelID.Location = new Point(135, 65);
            labelID.Name = "labelID";
            labelID.Size = new Size(82, 20);
            labelID.TabIndex = 7;
            labelID.Text = "Student ID:";
            // 
            // numericUpDownAge
            // 
            numericUpDownAge.Location = new Point(273, 212);
            numericUpDownAge.Name = "numericUpDownAge";
            numericUpDownAge.Size = new Size(150, 27);
            numericUpDownAge.TabIndex = 8;
            // 
            // labelCourse
            // 
            labelCourse.AutoSize = true;
            labelCourse.Location = new Point(138, 267);
            labelCourse.Name = "labelCourse";
            labelCourse.Size = new Size(57, 20);
            labelCourse.TabIndex = 9;
            labelCourse.Text = "Course:";
            // 
            // comboBoxCourse
            // 
            comboBoxCourse.FormattingEnabled = true;
            comboBoxCourse.Items.AddRange(new object[] { "BIT", "BCOMP", "DIT" });
            comboBoxCourse.Location = new Point(272, 270);
            comboBoxCourse.Name = "comboBoxCourse";
            comboBoxCourse.Size = new Size(151, 28);
            comboBoxCourse.TabIndex = 10;
            comboBoxCourse.DropDownStyle = ComboBoxStyle.DropDownList;

            // 
            // buttonSubmit
            // 
            buttonSubmit.Location = new Point(147, 339);
            buttonSubmit.Name = "buttonSubmit";
            buttonSubmit.Size = new Size(94, 29);
            buttonSubmit.TabIndex = 11;
            buttonSubmit.Text = "Submit";
            buttonSubmit.UseVisualStyleBackColor = true;
            buttonSubmit.Click += buttonSubmit_Click;
            // 
            // AddNew
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonSubmit);
            Controls.Add(comboBoxCourse);
            Controls.Add(labelCourse);
            Controls.Add(numericUpDownAge);
            Controls.Add(labelID);
            Controls.Add(labelAge);
            Controls.Add(numericUpDownID);
            Controls.Add(textBoxLastName);
            Controls.Add(labelLastName);
            Controls.Add(textBoxFirstName);
            Controls.Add(labelFirstName);
            Controls.Add(buttonHome);
            Name = "AddNew";
            Text = "Add";
            ((System.ComponentModel.ISupportInitialize)numericUpDownID).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownAge).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonHome;
        private Label labelFirstName;
        private TextBox textBoxFirstName;
        private TextBox textBoxLastName;
        private Label labelLastName;
        private NumericUpDown numericUpDownID;
        private Label labelAge;
        private Label labelID;
        private NumericUpDown numericUpDownAge;
        private Label labelCourse;
        private ComboBox comboBoxCourse;
        private Button buttonSubmit;
    }
}
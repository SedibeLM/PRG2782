﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRG2782_Project
{
    public partial class ViewAll : Form
    {
        public ViewAll()
        {
            InitializeComponent();
        }
        DataTable table = new DataTable();
        private void buttonHome_Click(object sender, EventArgs e) //TO GO BACK TO HOME PAGE
        {
            new Home().Show();
            this.Hide();
        }

        private void ViewAll_Load(object sender, EventArgs e)
        {
            table.Columns.Add("ID", typeof(int));
            table.Columns.Add("First Name", typeof(string));
            table.Columns.Add("Last Name", typeof(string));
            table.Columns.Add("Age", typeof(int));
            table.Columns.Add("Course", typeof(string));

            dataGridView1.DataSource = table;
        }


        private void buttonShow_Click(object sender, EventArgs e)
        {
            string fileName = Path.GetFileName("students.txt");
            string[] lines = File.ReadAllLines(fileName);
            string[] values;

            for (int i = 0; i < lines.Length; i++)
            {
                values = lines[i].ToString().Split(",");
                string[] row = new string[values.Length];

                for (int j = 0; j < values.Length; j++)
                {
                    row[j] = values[j].Trim();

                }
                
                table.Rows.Add(row);
            }
        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRG2782_Project
{
    public partial class Report : Form
    {
        public Report()
        {
            InitializeComponent();
        }

        private void buttonHome_Click(object sender, EventArgs e) //TO GO BACK TO HOME PAGE
        {
            new Home().Show();
            this.Hide();
        }


    }
}

namespace PRG2782_Project
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void buttonAdd_Click(object sender, EventArgs e) //TO ADD NEW STUDENT
        {
            new AddNew().Show();
            this.Hide();
        }

        private void buttonDelete_Click(object sender, EventArgs e) //TO DELETE A STUDENT
        {
            new Delete().Show();
            this.Hide();
        }

        private void buttonUpdate_Click(object sender, EventArgs e) //TO UPDATE AN EXISTING STUDENT
        {
            new Update().Show();
            this.Hide();
        }

        private void buttonView_Click(object sender, EventArgs e)
        {
            new ViewAll().Show();
            this.Hide();
        }

        private void buttonReport_Click(object sender, EventArgs e)
        {
            new Report().Show();
            this.Hide();
        }
    }
}
